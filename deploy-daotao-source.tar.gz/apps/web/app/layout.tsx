import type { Metadata, Viewport } from 'next';
import { AuthProvider } from '@/components/auth-provider';
import './globals.css';

export const metadata: Metadata = {
  title: 'MKT Academy — Học để chiến thắng',
  description:
    'Nền tảng đào tạo nhân sự dạng game hóa của Phần mềm MKT — học, thi, lên cấp, nhận thưởng.',
  applicationName: 'MKT Academy',
  icons: {
    icon: '/brand/mkt-logo-vertical-positive.png',
    apple: '/brand/mkt-logo-vertical-positive.png',
  },
  authors: [{ name: 'Phần mềm MKT' }],
};

export const viewport: Viewport = {
  themeColor: '#6FA9F9',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }): JSX.Element {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body className="min-h-screen text-white antialiased">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
