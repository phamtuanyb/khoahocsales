/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Cho phép import package monorepo @mkt-academy/types
  transpilePackages: ['@mkt-academy/types'],
  experimental: {
    typedRoutes: true,
  },
};

export default nextConfig;
