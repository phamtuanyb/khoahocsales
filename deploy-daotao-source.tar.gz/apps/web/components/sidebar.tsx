'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { UserRole } from '@mkt-academy/types';
import { BrandLogo } from '@/components/brand-logo';
import { useAuth } from './auth-provider';
import { findAvatar } from '@/lib/avatars';

interface NavItem {
  href: string;
  label: string;
  icon: string;
  roles?: UserRole[];
}

const NAV: readonly NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: '🏠' },
  { href: '/dashboard/learn', label: 'Khu vực học', icon: '📚' },
  { href: '/dashboard/leaderboard', label: 'Bảng xếp hạng', icon: '🏆' },
  { href: '/dashboard/badges', label: 'Huy hiệu', icon: '🎖' },
  { href: '/dashboard/certificates', label: 'Chứng chỉ', icon: '📜' },
  { href: '/dashboard/ai-coach', label: 'AI Coach', icon: '🤖' },
  { href: '/dashboard/team', label: 'Theo dõi team', icon: '👥', roles: [UserRole.MANAGER, UserRole.ADMIN] },
  { href: '/dashboard/admin', label: 'Quản trị', icon: '⚙️', roles: [UserRole.ADMIN] },
  { href: '/dashboard/guide', label: 'Hướng dẫn', icon: '📖' },
];

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps): JSX.Element {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const avatar = findAvatar(user?.profile?.avatar ?? null);
  const visibleNav = NAV.filter((item) => !item.roles || (user && item.roles.includes(user.role)));

  return (
    <aside
      className={`
        fixed inset-y-0 left-0 z-40 flex h-screen w-72 shrink-0 flex-col gap-6
        border-r border-[#E6E3E7] bg-white p-6 shadow-[12px_0_38px_rgba(28,41,61,0.08)]
        transition-transform duration-300
        lg:sticky lg:top-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}
    >
      <button
        type="button"
        onClick={onClose}
        className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-[#EAF3FF] text-lg font-black text-[#005AB3] lg:hidden"
        aria-label="Đóng menu"
      >
        ×
      </button>

      <Link href="/dashboard" onClick={onClose} className="block">
        <BrandLogo variant="horizontal-positive" priority className="h-auto w-44 object-contain" />
      </Link>

      {user && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-[#D9E7FF] bg-[#F8FBFF] p-3"
        >
          <div className="flex items-center gap-3">
            <div
              className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${avatar.bg} text-2xl ring-2 ${avatar.ring}`}
            >
              {avatar.emoji}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-black text-[#1B1B1D]">{user.name}</div>
              <div className="truncate text-[10px] font-black uppercase tracking-widest text-[#0073E0]">
                {roleLabel(user.role)}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto">
        {visibleNav.map((item) => {
          const active =
            item.href === '/dashboard' ? pathname === '/dashboard' : pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-black uppercase tracking-wide transition ${
                active
                  ? 'bg-[#FF7A00] text-white shadow-[0_12px_24px_rgba(255,122,0,0.24)]'
                  : 'text-[#414754] hover:bg-[#EAF3FF] hover:text-[#005AB3]'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <button
        type="button"
        onClick={logout}
        className="rounded-xl border border-[#D9E7FF] px-3 py-2.5 text-sm font-black uppercase tracking-wide text-[#005AB3] transition hover:border-[#FF7A00] hover:text-[#FF7A00]"
      >
        ⎋ Đăng xuất
      </button>
    </aside>
  );
}

function roleLabel(role: UserRole): string {
  switch (role) {
    case UserRole.ADMIN:
      return 'Quản trị viên';
    case UserRole.MANAGER:
      return 'Trưởng phòng';
    case UserRole.LEARNER:
      return 'Nhân sự';
    default:
      return role;
  }
}
